let contador = 0;

function ctt() {
    let numeroAnterior = contador;
    contador++;
    return numeroAnterior
}

export { ctt };