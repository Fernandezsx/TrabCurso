const adminid = [{
            usuarioAdm: 'Camavinga',
            senhaAdmin: '12345',
            role: 'apoiador Moral'
        },
        {
            usuarioAdm: 'wl',
            senhaAdmin: '731',
            role: 'pre programador'
        },
        {
            usuarioAdm: 'jh',
            senhaAdmin: 'zeDamanga',
            role: 'Gestor de Codigo'
        }
    ]
    /*
    let produto = {
        idprod: null,
        nomeProd: null,
        idCategoria: null,
        imgprod: null,
        disponivel: null
    }*/
module.exports = {
    adminid
}